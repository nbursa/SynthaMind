package utils

// Task structure for AI processing
type Task struct {
	ID   int
	Data string
}
